import React from "react";
import HeaderComponent from "./HeaderComponents";
import ProjectNameCompo from "./ProjectNameCompo";
import ListForm from "./ListForm"

export default class ProjectList extends React.Component
{
    constructor(props)
    {
        super(props);
        this.showStatus=this.showStatus.bind(this);
        this.deleteList=this.deleteList.bind(this);
        this.addList=this.addList.bind(this);
        this.updateList=this.updateList.bind(this);
        this.editList=this.editList.bind(this);
        {
            this.state={
                list:[
                    {name:"SLB",completed:false},
                    {name:"TCI",completed:false},
                    {name:"MERK",completed:false}],
                    currentList:''
            };
        }
       
    }
    showStatus(index)
    {
        var list = this.state.list;
        var list1 = list[index];
        list1.completed=!list1.completed;
        this.setState({
            list:list
        });
        console.log(this.state.list[index]);
    }
    deleteList(listToBeDelete)
    {
        
        let list=this.state.list;
        list.splice(listToBeDelete,1);
        this.setState({list:list});
    }

    updateList(newList)
    {
        this.setState({
            currentList:newList.target.value
        });
    }
    
    addList(e)
    {
        e.preventDefault();
        console.log("added")
        let list=this.state.list;
        let currentList=this.state.currentList;
        list.push({name:currentList,completed:false});
        this.setState({list:list,currentList:''})
    }
    editList(listToBeUpdate)
    {
        let list=this.state.list;
        // list.addList(this.state.listToBeUpdate);
       
           // currentList:listToBeUpdate;
     
        // let editList=this.state.currentList;
        this.setState({list:list,currentList:listToBeUpdate.target.value})
        //this.setState({list:list});
    }
    render()
    {
        return(
            <div>
                <HeaderComponent/>
                <ul>
                    <section>
                        <ListForm currentList={this.state.currentList} 
                        updateList={this.updateList} 
                        addList={this.addList}/>
                    </section>
                    
                    {this.state.list.map((list,index)=>{
                        return<ProjectNameCompo key={list.name} list={list} index={index} 
                        statushandler={this.showStatus}
                        deleteList={this.deleteList}
                        editList={this.editList}/>
                    })}
                    
                    
                </ul>
            </div>
        );
    }
}