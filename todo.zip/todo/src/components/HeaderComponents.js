import React from 'react';
class HeaderComponent extends React.Component{
    constructor(props)
    {
        super(props);
        {
            this.state={
                Header:"My Project details",
                Logo:"PMS"
            };
        }
            
    }

    render()
    {
        return(
            <div>
                <h1>welcome to header</h1>
                <h1>{this.state.Header}</h1>
                <h1>{this.state.Logo}</h1>
            </div>
        );
    }
}
export default HeaderComponent
