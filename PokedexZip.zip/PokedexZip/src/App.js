import React from "react";
import Pokegame from "./Pokegame";

/** Main App component. */

function App() {
  return (
      <div className="App">
        <Pokegame />
      </div>
  );
}

export default App;
